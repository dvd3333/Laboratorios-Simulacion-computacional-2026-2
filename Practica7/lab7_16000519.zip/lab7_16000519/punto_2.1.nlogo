;; =====================================================================
;;  Autómata celular de la REGLA DE PARIDAD (Parity Rule)
;;  Laboratorio 7 - Simulación Computacional (Unillanos)
;;
;;  Cada celda (patch) tiene un estado binario: 0 (muerta) o 1 (viva).
;;  En cada paso de tiempo TODAS las celdas se actualizan a la vez
;;  (actualización síncrona) con la regla:
;;
;;     s(t+1) = s_N(t) XOR s_E(t) XOR s_S(t) XOR s_W(t)
;;
;;  es decir, el nuevo estado es la suma de los vecinos módulo 2:
;;  1 si hay un número IMPAR de vecinos vivos, 0 si es PAR.
;;  El vecindario por defecto es el de von Neumann (4 vecinos), que es
;;  la versión clásica (Chopard y Droz). El selector "vecindario"
;;  permite probar también Moore (8) y las variantes con la celda central.
;; =====================================================================

patches-own [
  estado          ;; 0 o 1 en el tiempo t
  estado-nuevo    ;; valor calculado para t+1
]

;; ---------------------------------------------------------------------
;; Inicialización
;; ---------------------------------------------------------------------
to setup
  clear-all
  ask patches [ set estado 0 ]
  patron-inicial
  ask patches [ colorear ]
  reset-ticks
end

to patron-inicial
  if condicion-inicial = "una celda" [
    ask patch 0 0 [ set estado 1 ]
  ]
  if condicion-inicial = "cuadrado 3x3" [
    ask patches with [ abs pxcor <= 1 and abs pycor <= 1 ] [ set estado 1 ]
  ]
  if condicion-inicial = "letra L" [
    ask patches with [ pxcor = -2 and pycor >= -3 and pycor <= 3 ] [ set estado 1 ]
    ask patches with [ pycor = -3 and pxcor >= -2 and pxcor <= 2 ] [ set estado 1 ]
  ]
  if condicion-inicial = "bloque aleatorio 9x9" [
    ask patches with [ abs pxcor <= 4 and abs pycor <= 4 ] [
      if random-float 1 < densidad [ set estado 1 ]
    ]
  ]
  if condicion-inicial = "todo aleatorio" [
    ask patches [ if random-float 1 < densidad [ set estado 1 ] ]
  ]
end

;; ---------------------------------------------------------------------
;; Dinámica
;; ---------------------------------------------------------------------
to go
  ;; Paso 1: cada celda calcula su próximo estado mirando el tiempo t
  ask patches [
    set estado-nuevo (suma-vecindario mod 2)
  ]
  ;; Paso 2: se actualizan todas a la vez (regla síncrona)
  ask patches [
    set estado estado-nuevo
    colorear
  ]
  tick
end

;; Suma de los estados del vecindario elegido
to-report suma-vecindario
  if vecindario = "von Neumann (4)" [
    report sum [estado] of neighbors4
  ]
  if vecindario = "von Neumann + centro (5)" [
    report estado + sum [estado] of neighbors4
  ]
  if vecindario = "Moore (8)" [
    report sum [estado] of neighbors
  ]
  ;; "Moore + centro (9)"
  report estado + sum [estado] of neighbors
end

to colorear  ;; procedimiento de patch
  ifelse estado = 1 [ set pcolor yellow ] [ set pcolor black ]
end

;; Avanza hasta el siguiente tiempo t = 2^n
to ir-a-siguiente-potencia
  go
  while [ not potencia-de-2? ] [ go ]
end

;; ---------------------------------------------------------------------
;; Dibujar / borrar celdas con el ratón (mantener pulsado el botón)
;; ---------------------------------------------------------------------
to dibujar
  if mouse-down? [
    ask patch mouse-xcor mouse-ycor [
      set estado 1
      colorear
    ]
    display
  ]
end

to borrar
  if mouse-down? [
    ask patch mouse-xcor mouse-ycor [
      set estado 0
      colorear
    ]
    display
  ]
end

;; ---------------------------------------------------------------------
;; Reporteros para monitores y gráfica
;; ---------------------------------------------------------------------
to-report celdas-vivas
  report count patches with [ estado = 1 ]
end

;; Devuelve true cuando ticks es potencia de 2 (1, 2, 4, 8, 16, ...),
;; los instantes en los que aparecen las réplicas del patrón inicial.
to-report potencia-de-2?
  if ticks < 1 [ report false ]
  let n ticks
  while [ n mod 2 = 0 ] [ set n n / 2 ]
  report n = 1
end
@#$#@#$#@
GRAPHICS-WINDOW
260
10
781
531
-1
-1
4.0
1
10
1
1
1
0
1
1
1
-64
64
-64
64
1
1
1
ticks
30.0

BUTTON
15
15
120
50
NIL
setup
NIL
1
T
OBSERVER
NIL
NIL
NIL
NIL
1

BUTTON
125
15
245
50
paso
go
NIL
1
T
OBSERVER
NIL
NIL
NIL
NIL
0

BUTTON
15
55
120
90
NIL
go
T
1
T
OBSERVER
NIL
NIL
NIL
NIL
0

BUTTON
125
55
245
90
ir a t = 2^n
ir-a-siguiente-potencia
NIL
1
T
OBSERVER
NIL
NIL
NIL
NIL
0

CHOOSER
15
100
245
145
vecindario
vecindario
"von Neumann (4)" "von Neumann + centro (5)" "Moore (8)" "Moore + centro (9)"
0

CHOOSER
15
150
245
195
condicion-inicial
condicion-inicial
"una celda" "cuadrado 3x3" "letra L" "bloque aleatorio 9x9" "todo aleatorio"
2

SLIDER
15
200
245
233
densidad
densidad
0.0
1.0
0.5
0.01
1
NIL
HORIZONTAL

BUTTON
15
240
120
273
dibujar
dibujar
T
1
T
OBSERVER
NIL
NIL
NIL
NIL
1

BUTTON
125
240
245
273
borrar
borrar
T
1
T
OBSERVER
NIL
NIL
NIL
NIL
1

MONITOR
15
280
120
325
celdas vivas
celdas-vivas
0
1
11

MONITOR
125
280
245
325
t es 2^n?
potencia-de-2?
17
1
11

PLOT
15
335
245
530
Celdas vivas
tiempo (ticks)
celdas vivas
0.0
10.0
0.0
10.0
true
false
"" ""
PENS
"vivas" 1.0 0 -16777216 true "" "plot celdas-vivas"

@#$#@#$#@
## ¿QUÉ ES?

Un autómata celular bidimensional con la **regla de paridad** (*parity rule*). Cada celda (patch) tiene dos estados posibles: 0 (negro) o 1 (amarillo).

## CÓMO FUNCIONA

En cada paso de tiempo todas las celdas se actualizan **a la vez** (de forma síncrona). El nuevo estado de una celda es la suma de los estados de sus vecinos **módulo 2**, es decir, el XOR (o exclusivo) de los vecinos:

    s(t+1) = s_N(t) ⊕ s_E(t) ⊕ s_S(t) ⊕ s_W(t)

Si hay un número **impar** de vecinos vivos, la celda queda viva (1). Si el número es **par**, queda muerta (0).

Para que la actualización sea síncrona, `go` hace dos pasadas:

1. Cada patch calcula `estado-nuevo` con los estados del tiempo t.
2. Todos copian `estado-nuevo` en `estado` al mismo tiempo.

El mundo es un toro: los bordes se conectan entre sí.

## CÓMO USARLO

1. Elige el **vecindario**. El clásico es *von Neumann (4)*: norte, sur, este y oeste.
2. Elige la **condicion-inicial**: una celda, un cuadrado 3x3, una letra L, un bloque aleatorio 9x9 o todo el mundo aleatorio. La **densidad** solo se usa en las dos opciones aleatorias.
3. Pulsa **setup** y luego **paso**, **go** o **ir a t = 2^n**.
4. Con **dibujar** y **borrar** activos, puedes crear o borrar tu propio patrón con el ratón.

## COSAS PARA OBSERVAR

- **Auto-replicación:** en los tiempos t = 2, 4, 8, 16, 32, ... el patrón inicial aparece **copiado**. Con von Neumann (4) salen 4 copias desplazadas ±t en x y en y. El botón *ir a t = 2^n* salta directamente a esos instantes.
- Entre potencias de 2 se forman patrones fractales y complejos, aunque la regla es muy simple.
- El número de copias depende del vecindario: 5 con von Neumann + centro, 8 con Moore y 9 con Moore + centro.
- Como el mundo mide 129 x 129 y es un toro, a partir de t ≈ 64 las copias se cruzan por los bordes y se mezclan.

## ¿POR QUÉ SE REPLICA?

La regla es **lineal** en aritmética módulo 2: la evolución de una suma (XOR) de patrones es la suma de sus evoluciones. Aplicar la regla t veces equivale a elevar el polinomio de vecindad (x + x⁻¹ + y + y⁻¹) a la t. Cuando t = 2^n, en módulo 2 todos los términos cruzados se cancelan y queda x^t + x^-t + y^t + y^-t: cuatro copias desplazadas t celdas.

## REFERENCIAS

- B. Chopard y M. Droz, *Cellular Automata Modeling of Physical Systems*, Cambridge University Press, 1998 (sección de la regla de paridad).
- Presentación "Cellular Automata" del curso Simulación Computacional, Unillanos.

@#$#@#$#@
default
true
0
Polygon -7500403 true true 150 5 40 250 150 205 260 250

airplane
true
0
Polygon -7500403 true true 150 0 135 15 120 60 120 105 15 165 15 195 120 180 135 240 105 270 120 285 150 270 180 285 210 270 165 240 180 180 285 195 285 165 180 105 180 60 165 15

arrow
true
0
Polygon -7500403 true true 150 0 0 150 105 150 105 293 195 293 195 150 300 150

box
false
0
Polygon -7500403 true true 150 285 285 225 285 75 150 135
Polygon -7500403 true true 150 135 15 75 150 15 285 75
Polygon -7500403 true true 15 75 15 225 150 285 150 135
Line -16777216 false 150 285 150 135
Line -16777216 false 150 135 15 75
Line -16777216 false 150 135 285 75

bug
true
0
Circle -7500403 true true 96 182 108
Circle -7500403 true true 110 127 80
Circle -7500403 true true 110 75 80
Line -7500403 true 150 100 80 30
Line -7500403 true 150 100 220 30

butterfly
true
0
Polygon -7500403 true true 150 165 209 199 225 225 225 255 195 270 165 255 150 240
Polygon -7500403 true true 150 165 89 198 75 225 75 255 105 270 135 255 150 240
Polygon -7500403 true true 139 148 100 105 55 90 25 90 10 105 10 135 25 180 40 195 85 194 139 163
Polygon -7500403 true true 162 150 200 105 245 90 275 90 290 105 290 135 275 180 260 195 215 195 162 165
Polygon -16777216 true false 150 255 135 225 120 150 135 120 150 105 165 120 180 150 165 225
Circle -16777216 true false 135 90 30
Line -16777216 false 150 105 195 60
Line -16777216 false 150 105 105 60

car
false
0
Polygon -7500403 true true 300 180 279 164 261 144 240 135 226 132 213 106 203 84 185 63 159 50 135 50 75 60 0 150 0 165 0 225 300 225 300 180
Circle -16777216 true false 180 180 90
Circle -16777216 true false 30 180 90
Polygon -16777216 true false 162 80 132 78 134 135 209 135 194 105 189 96 180 89
Circle -7500403 true true 47 195 58
Circle -7500403 true true 195 195 58

circle
false
0
Circle -7500403 true true 0 0 300

circle 2
false
0
Circle -7500403 true true 0 0 300
Circle -16777216 true false 30 30 240

cow
false
0
Polygon -7500403 true true 200 193 197 249 179 249 177 196 166 187 140 189 93 191 78 179 72 211 49 209 48 181 37 149 25 120 25 89 45 72 103 84 179 75 198 76 252 64 272 81 293 103 285 121 255 121 242 118 224 167
Polygon -7500403 true true 73 210 86 251 62 249 48 208
Polygon -7500403 true true 25 114 16 195 9 204 23 213 25 200 39 123

cylinder
false
0
Circle -7500403 true true 0 0 300

dot
false
0
Circle -7500403 true true 90 90 120

face happy
false
0
Circle -7500403 true true 8 8 285
Circle -16777216 true false 60 75 60
Circle -16777216 true false 180 75 60
Polygon -16777216 true false 150 255 90 239 62 213 47 191 67 179 90 203 109 218 150 225 192 218 210 203 227 181 251 194 236 217 212 240

face neutral
false
0
Circle -7500403 true true 8 7 285
Circle -16777216 true false 60 75 60
Circle -16777216 true false 180 75 60
Rectangle -16777216 true false 60 195 240 225

face sad
false
0
Circle -7500403 true true 8 8 285
Circle -16777216 true false 60 75 60
Circle -16777216 true false 180 75 60
Polygon -16777216 true false 150 168 90 184 62 210 47 232 67 244 90 220 109 205 150 198 192 205 210 220 227 242 251 229 236 206 212 183

fish
false
0
Polygon -1 true false 44 131 21 87 15 86 0 120 15 150 0 180 13 214 20 212 45 166
Polygon -1 true false 135 195 119 235 95 218 76 210 46 204 60 165
Polygon -1 true false 75 45 83 77 71 103 86 114 166 78 135 60
Polygon -7500403 true true 30 136 151 77 226 81 280 119 292 146 292 160 287 170 270 195 195 210 151 212 30 166
Circle -16777216 true false 215 106 30

flag
false
0
Rectangle -7500403 true true 60 15 75 300
Polygon -7500403 true true 90 150 270 90 90 30
Line -7500403 true 75 135 90 135
Line -7500403 true 75 45 90 45

flower
false
0
Polygon -10899396 true false 135 120 165 165 180 210 180 240 150 300 165 300 195 240 195 195 165 135
Circle -7500403 true true 85 132 38
Circle -7500403 true true 130 147 38
Circle -7500403 true true 192 85 38
Circle -7500403 true true 85 40 38
Circle -7500403 true true 177 40 38
Circle -7500403 true true 177 132 38
Circle -7500403 true true 70 85 38
Circle -7500403 true true 130 25 38
Circle -7500403 true true 96 51 108
Circle -16777216 true false 113 68 74
Polygon -10899396 true false 189 233 219 188 249 173 279 188 234 218
Polygon -10899396 true false 180 255 150 210 105 210 75 240 135 240

house
false
0
Rectangle -7500403 true true 45 120 255 285
Rectangle -16777216 true false 120 210 180 285
Polygon -7500403 true true 15 120 150 15 285 120
Line -16777216 false 30 120 270 120

leaf
false
0
Polygon -7500403 true true 150 210 135 195 120 210 60 210 30 195 60 180 60 165 15 135 30 120 15 105 40 104 45 90 60 90 90 105 105 120 120 120 105 60 120 60 135 30 150 15 165 30 180 60 195 60 180 120 195 120 210 105 240 90 255 90 263 104 285 105 270 120 285 135 240 165 240 180 270 195 240 210 180 210 165 195
Polygon -7500403 true true 135 195 135 240 120 255 105 255 105 285 135 285 165 240 165 195

line
true
0
Line -7500403 true 150 0 150 300

line half
true
0
Line -7500403 true 150 0 150 150

pentagon
false
0
Polygon -7500403 true true 150 15 15 120 60 285 240 285 285 120

person
false
0
Circle -7500403 true true 110 5 80
Polygon -7500403 true true 105 90 120 195 90 285 105 300 135 300 150 225 165 300 195 300 210 285 180 195 195 90
Rectangle -7500403 true true 127 79 172 94
Polygon -7500403 true true 195 90 240 150 225 180 165 105
Polygon -7500403 true true 105 90 60 150 75 180 135 105

plant
false
0
Rectangle -7500403 true true 135 90 165 300
Polygon -7500403 true true 135 255 90 210 45 195 75 255 135 285
Polygon -7500403 true true 165 255 210 210 255 195 225 255 165 285
Polygon -7500403 true true 135 180 90 135 45 120 75 180 135 210
Polygon -7500403 true true 165 180 165 210 225 180 255 120 210 135
Polygon -7500403 true true 135 105 90 60 45 45 75 105 135 135
Polygon -7500403 true true 165 105 165 135 225 105 255 45 210 60
Polygon -7500403 true true 135 90 120 45 150 15 180 45 165 90

square
false
0
Rectangle -7500403 true true 30 30 270 270

square 2
false
0
Rectangle -7500403 true true 30 30 270 270
Rectangle -16777216 true false 60 60 240 240

star
false
0
Polygon -7500403 true true 151 1 185 108 298 108 207 175 242 282 151 216 59 282 94 175 3 108 116 108

target
false
0
Circle -7500403 true true 0 0 300
Circle -16777216 true false 30 30 240
Circle -7500403 true true 60 60 180
Circle -16777216 true false 90 90 120
Circle -7500403 true true 120 120 60

tree
false
0
Circle -7500403 true true 118 3 94
Rectangle -6459832 true false 120 195 180 300
Circle -7500403 true true 65 21 108
Circle -7500403 true true 116 41 127
Circle -7500403 true true 45 90 120
Circle -7500403 true true 104 74 152

triangle
false
0
Polygon -7500403 true true 150 30 15 255 285 255

triangle 2
false
0
Polygon -7500403 true true 150 30 15 255 285 255
Polygon -16777216 true false 151 99 225 223 75 224

truck
false
0
Rectangle -7500403 true true 4 45 195 187
Polygon -7500403 true true 296 193 296 150 259 134 244 104 208 104 207 194
Rectangle -1 true false 195 60 195 105
Polygon -16777216 true false 238 112 252 141 219 141 218 112
Circle -16777216 true false 234 174 42
Rectangle -7500403 true true 181 185 214 194
Circle -16777216 true false 144 174 42
Circle -16777216 true false 24 174 42
Circle -7500403 false true 24 174 42
Circle -7500403 false true 144 174 42
Circle -7500403 false true 234 174 42

turtle
true
0
Polygon -10899396 true false 215 204 240 233 246 254 228 266 215 252 193 210
Polygon -10899396 true false 195 90 225 75 245 75 260 89 269 108 261 124 240 105 225 105 210 105
Polygon -10899396 true false 105 90 75 75 55 75 40 89 31 108 39 124 60 105 75 105 90 105
Polygon -10899396 true false 132 85 134 64 107 51 108 17 150 2 192 18 192 52 169 65 172 87
Polygon -10899396 true false 85 204 60 233 54 254 72 266 85 252 107 210
Polygon -7500403 true true 119 75 179 75 209 101 224 135 220 225 175 261 128 261 81 224 74 135 88 99

wheel
false
0
Circle -7500403 true true 3 3 294
Circle -16777216 true false 30 30 240
Line -7500403 true 150 285 150 15
Line -7500403 true 15 150 285 150
Circle -7500403 true true 120 120 60
Line -7500403 true 216 40 79 269
Line -7500403 true 40 84 269 221
Line -7500403 true 40 216 269 79
Line -7500403 true 84 40 221 269

x
false
0
Polygon -7500403 true true 270 75 225 30 30 225 75 270
Polygon -7500403 true true 30 75 75 30 270 225 225 270
@#$#@#$#@
NetLogo 6.4.0
@#$#@#$#@
setup repeat 32 [ go ]
@#$#@#$#@
@#$#@#$#@
@#$#@#$#@
@#$#@#$#@
default
0.0
-0.2 0 0.0 1.0
0.0 1 1.0 0.0
0.2 0 0.0 1.0
link direction
true
0
Line -7500403 true 150 150 90 180
Line -7500403 true 150 150 210 180
@#$#@#$#@
0
@#$#@#$#@
